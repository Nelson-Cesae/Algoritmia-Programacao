package Enums;

public enum AlimentacaoAnimal {

    CARNIVORO, HERBIVORO, OMNIVORO
}
