package Enums;

public enum FamiliaPlanta {

    ARVORES, FLORES, ERVAS, COMEINSETOS
}
